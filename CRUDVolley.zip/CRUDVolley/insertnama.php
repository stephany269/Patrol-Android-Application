<?php
include "connection.php";
$pass = $_GET["pass"];
$id = $_GET["id"];
$datemasuk = $_GET["datemasuk"];
class emp{}
if(empty($pass) || empty($id) || empty($datemasuk)){
  echo "Isian tidak boleh kosong";
} else{

  $query = pg_query($conn, "UPDATE karyawan SET datetime_masuk ='".$datemasuk."' WHERE id_karyawan = '".$id."' ");
  $query2 = pg_query($conn, "INSERT INTO petugas_patroli(id_karyawan, password_petugas, datetime_masuk) VALUES ('".$id."','".$pass."','".$datemasuk."')");
  if($query && $query2) echo "Berhasil disimpan";
  if(!$query2 || !$query) echo "Registrasi Gagal";
}
?>