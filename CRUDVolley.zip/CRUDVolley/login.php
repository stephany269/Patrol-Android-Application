<?php
include "connection.php";
$id_petugas = $_GET["id_petugas"];
$datelogin = $_GET["datelogin"];
$id_karyawan = $_GET["id_karyawan"];
  $query = pg_query($conn, "UPDATE petugas_patroli SET datetime_last_login='".$datelogin."' WHERE id_petugas_patroli = $id_petugas");
  $query2 = pg_query($conn, "INSERT INTO absensi(id_karyawan, datetime_absen) VALUES ('".$id_karyawan."','".$datelogin."')");
  if($query) echo "Login success";
  else{
    echo "Login failed";
  } 
?>