<?php
include "connection.php";
$nama_lokasi = $_GET["nama_lokasi"];
$upperc = strtolower($_GET["nama_lokasi"]);
$lowerc = strtoupper($_GET["nama_lokasi"]);
$capi = ucwords($nama_lokasi);
$sapi = lcfirst($nama_lokasi);
$capit = ucfirst($nama_lokasi);
$cipa = ucwords(strtolower($nama_lokasi));

if(!$conn){
    echo 'Connection Faild: '.$conn->connect_error;
}
else{
    $query=pg_query ($conn, "SELECT * from lokasi_kartu_patroli where nama_lokasi like '%$nama_lokasi%' 
                            or nama_lokasi like '%$upperc%' 
                            or nama_lokasi like '%$lowerc%' 
                            or nama_lokasi like '%$capi%'
                            or nama_lokasi like '%$sapi%'
                            or nama_lokasi like '%$capit%'
                            or nama_lokasi like '%$cipa%'
                            ");
    $json = array();
    while($row = pg_fetch_assoc($query)){
        $json[] = $row;
    }
    echo json_encode($json);
    pg_close($conn);
}

?>