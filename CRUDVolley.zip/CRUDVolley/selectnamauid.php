<?php
include "connection.php";
$nama = $_GET["nama"];
$kartu = $_GET["kartu"];

if(!$conn){
    echo 'Connection Faild: '.$conn->connect_error;
}
else{
    $query=pg_query ($conn, "SELECT * from lokasi_kartu_patroli where nama_lokasi = '".$nama."' 
                            or uid = '".$kartu."'
                            ");
    $json = array();
    while($row = pg_fetch_assoc($query)){
        $json[] = $row;
    }
    echo json_encode($json);
    pg_close($conn);
}

?>