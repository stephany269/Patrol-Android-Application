<?php
include "connection.php";
$id_patroli = $_GET["id_patroli"];

if(!$conn){
    echo 'Connection Failed: '.$conn->connect_error;
}
else{
    $query = pg_query($conn, "select e.*, l.nama_lokasi
                            from lokasi_kartu_patroli as l, event_patroli as e
                            where e.id_patroli = $id_patroli
                            and
                            l.uid = e.uid_kartu_patroli
                            ");

    if(!$query) echo "Failed fetching data";
    else{
        $json = array();
        while($row = pg_fetch_assoc($query)){
        $json[] = $row;
        }
        echo json_encode($json);
        pg_close($conn);
    }
}

?>