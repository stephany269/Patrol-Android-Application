<?php
include "connection.php";
$id_karyawan = $_GET["id_karyawan"];

if(!$conn){
    echo 'Connection Failed: '.$conn->connect_error;
}
else{
    $query = pg_query($conn, "select k.id_karyawan, p.id_petugas_patroli, k.nama, b.nama_bagian, l.nama_level
                            from petugas_patroli as p, karyawan as k , bagian_karyawan as b, level_karyawan as l
                            where p.id_karyawan = k.id_karyawan and l.id_level = k.id_level and
                            k.id_bagian = b.id_bagian and p.id_karyawan = $id_karyawan");
    if(!$query) echo "Failed fetching data";
    else{
        $json = array();
        while($row = pg_fetch_assoc($query)){
        $json[] = $row;
        }
        echo json_encode($json);
        pg_close($conn);
    }
}

?>