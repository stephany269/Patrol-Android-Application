<?php
$dbuser = "postgres";
$dbpass = "meimei123";
$host = "localhost";
$dbname = "patroli";
$port = '5433';

// script koneksi php postgree
//$link = new PDO("pgsql:dbname=$dbname;host=$host", $dbuser, $dbpass); 
$conn_string = "host=localhost port=5433 dbname=patroli  
                    user=postgres password=meimei123";

$conn = pg_connect($conn_string);

?>
