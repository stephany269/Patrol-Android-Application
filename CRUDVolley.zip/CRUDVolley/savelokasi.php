<?php
include "connection.php";
$namalokasi = isset($_POST['namalokasi']) ? $_POST['namalokasi'] : '';
$getuid = isset($_POST['getuid']) ? $_POST['getuid'] :'';
$lokasi =isset($_POST['lokasi']) ? $_POST['lokasi'] : '';
class emp{}
if(empty($namalokasi) || empty($getuid) || empty($lokasi)){
  echo "Isian tidak boleh kosong";
} else{
  $query = pg_query($conn, "INSERT INTO lokasi_kartu_patroli(nama_lokasi, uid, lokasi_gps) VALUES ('".$namalokasi."','".$getuid."','".$lokasi."')");
  if($query) echo "Data saved successfully";
  if(!$query) echo "Error in saving data";
}
?>