<?php
include "connection.php";

$nama_lokasi = $_GET["nama_lokasi"];
$idx = $_GET["idx"];
$lokasi_gps = $_GET["lokasi_gps"];
$uid = $_GET["uid"];
$query = pg_query($conn, "UPDATE lokasi_kartu_patroli SET nama_lokasi='".$nama_lokasi."',
                          lokasi_gps = '".$lokasi_gps."',
                          uid = '".$uid."'
                          WHERE id_lokasi_patroli = $idx
                          ");
if(!$query){
  echo "Failed update data";
}
else{
  echo "Success update data";
}
?>