<?php
include "connection.php";
$query = pg_query($conn, "SELECT * FROM lokasi_kartu_patroli order by id_lokasi_patroli");
$json = array();
while($row = pg_fetch_assoc($query)){
    $json[] = $row;
}
echo json_encode($json);
pg_close($conn);
?>