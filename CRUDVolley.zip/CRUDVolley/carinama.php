<?php
include "connection.php";
$nama = $_GET["nama"];
$upperc = strtolower($_GET["nama"]);
$lowerc = strtoupper($_GET["nama"]);
$capi = ucwords($nama);
$sapi = lcfirst($nama);
$capit = ucfirst($nama);
$cipa = ucwords(strtolower($nama));

if(!$conn){
    echo 'Connection Faild: '.$conn->connect_error;
}
else{
    $query=pg_query ($conn, "SELECT * from karyawan where nama like '%$nama%' 
                            or nama like '%$upperc%' 
                            or nama like '%$lowerc%' 
                            or nama like '%$capi%'
                            or nama like '%$sapi%'
                            or nama like '%$capit%'
                            or nama like '%$cipa%'
                            ");
    $json = array();
    while($row = pg_fetch_assoc($query)){
        $json[] = $row;
    }
    echo json_encode($json);
    pg_close($conn);
}

?>