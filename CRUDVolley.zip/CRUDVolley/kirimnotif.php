<?php

function push_notification_android($title, $message){

//API URL of FCM
$url = 'https://fcm.googleapis.com/fcm/send';

/*api_key available in:
Firebase Console -> Project Settings -> CLOUD MESSAGING -> Server key*/    
$api_key = 'AAAAVRU-csg:APA91bHjZoig4u53KOxV_BXYY2LRabD9tBPiAY6smjYXBQM56Uut93dZfU6tTm6JLJvhf4ga-Agxfu8vbq_nMjEVtcoBIKYBriqEy7m0kF92kWoDUX6mEQGUBfMScgbCfhH71vmqFrgr';
            
$fields = array (
    'to'=>'/topics/news',
    'notification' => array(
        'title'=>$title,
        'body'=>$message
    ),
    
);

//header includes Content type and api key
$headers = array(
    'Content-Type:application/json',
    'Authorization:key='.$api_key
);
            
$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, $url);
curl_setopt($ch, CURLOPT_POST, true);
curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($fields));
$result = curl_exec($ch);
if ($result === FALSE) {
    die('FCM Send Error: ' . curl_error($ch));
}
curl_close($ch);
return $result;
}

?>