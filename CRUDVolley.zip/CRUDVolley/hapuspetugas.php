<?php
include "connection.php";
$id_petugas = $_GET["id_petugas"];
$id_karyawan = $_GET["id_karyawan"];
  $query = pg_query($conn, "DELETE FROM petugas_patroli WHERE id_petugas_patroli=$id_petugas");
  $query2 = pg_query($conn, "UPDATE karyawan SET datetime_masuk=NULL WHERE id_karyawan = $id_karyawan");
  if($query && $query2) echo "Officer has been removed";
  else{
    echo "Error remove data";
  } 
?>