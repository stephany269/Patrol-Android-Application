<?php
include "connection.php";
$id_petugas = $_GET["id_petugas"];

if(!$conn){
    echo 'Connection Failed: '.$conn->connect_error;
}
else{
    $query = pg_query($conn, "select p.*, k.nama
                            from petugas_patroli as p, karyawan as k
                            where p.id_petugas_patroli = $id_petugas and
                            p.id_karyawan = k.id_karyawan
                            ");

    if(!$query) echo "Failed fetching data";
    else{
        $json = array();
        while($row = pg_fetch_assoc($query)){
        $json[] = $row;
        }
        echo json_encode($json);
        pg_close($conn);
    }
}

?>