<?php
include "connection.php";
$query = pg_query($conn, "select p.id_petugas_patroli, k.nama, b.nama_bagian, k.datetime_masuk, l.nama_level 
                            from petugas_patroli as p, karyawan as k , bagian_karyawan as b, level_karyawan as l
                            where p.id_karyawan = k.id_karyawan and l.id_level = k.id_level and
                            k.id_bagian = b.id_bagian order by p.id_petugas_patroli");
$json = array();
while($row = pg_fetch_assoc($query)){
    $json[] = $row;
}
echo json_encode($json);
pg_close($conn);
?>