<?php
include "connection.php";
$id_lokasi_patroli = $_GET["id_lokasi_patroli"];
  $query = pg_query($conn, "DELETE FROM lokasi_kartu_patroli WHERE id_lokasi_patroli=$id_lokasi_patroli");
  if($query) echo "Location has been removed";
  if(!$query) echo "Error remove data";
?>