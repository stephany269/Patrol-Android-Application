<?php

include "connection.php";
include "kirimnotif.php";

$id_petugas = isset($_POST['id_petugas']) ? $_POST['id_petugas'] : '';
$nama_p = isset($_POST['nama_p']) ? $_POST['nama_p'] :'';
$uid_kp =isset($_POST['uid_kp']) ? $_POST['uid_kp'] : '';
$datepatrol =isset($_POST['datepatrol']) ? $_POST['datepatrol'] : '';
$gambar1 =isset($_POST['gambar1']) ? $_POST['gambar1'] : '';
$gambar2 =isset($_POST['gambar2']) ? $_POST['gambar2'] : '';
$gambar3 =isset($_POST['gambar3']) ? $_POST['gambar3'] : '';
$keter =isset($_POST['keter']) ? $_POST['keter'] : '';
class emp{}
if(empty($id_petugas) || empty($nama_p) || empty($uid_kp)){
  echo "Isian tidak boleh kosong";
} else {
    $query = pg_query($conn, "INSERT INTO event_patroli (id_petugas_patroli, nama_petugas, uid_kartu_patroli,
                                datetime_patroli, foto1, foto2, foto3, keterangan_patroli) 
    VALUES ('".$id_petugas."','".$nama_p."','".$uid_kp."', '".$datepatrol."', '".$gambar1."', 
            '".$gambar2."', '".$gambar3."', '".$keter."')");

            push_notification_android($nama_p, $keter);

    if($query) {
      echo "Berhasil disimpan";
    }
    if(!$query) echo "Gagal disimpan";
}

?>