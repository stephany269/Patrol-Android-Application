<?php
include "connection.php";

if(!$conn){
    echo 'Connection Failed: '.$conn->connect_error;
}
else{
    $query = pg_query($conn, "select e.*, l.nama_lokasi
                            from lokasi_kartu_patroli as l, event_patroli as e
                            where
                            l.uid = e.uid_kartu_patroli
                            order by
                            e.id_patroli
                            ");

    if(!$query) echo "Failed fetching data";
    else{
        $json = array();
        while($row = pg_fetch_assoc($query)){
        $json[] = $row;
        }
        echo json_encode($json);
        pg_close($conn);
    }
}

?>