<?php
include "connection.php";
$uidkartu = $_GET["uidkartu"];

if(!$conn){
    echo 'Connection Failed: '.$conn->connect_error;
}
else{
    $query = pg_query($conn, "select *
                            from lokasi_kartu_patroli
                            where uid like '%$uidkartu%'
                            ");
    if(!$query) echo "Failed fetching data";
    else{
        $json = array();
        while($row = pg_fetch_assoc($query)){
        $json[] = $row;
        }
        echo json_encode($json);
        pg_close($conn);
    }
}

?>